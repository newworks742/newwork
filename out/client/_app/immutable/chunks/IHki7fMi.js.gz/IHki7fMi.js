const e="4";typeof window<"u"&&(window.__svelte||(window.__svelte={v:new Set})).v.add(e);
