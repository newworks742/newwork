const s="Digitoad",t="https://img.partskeys.com/partskeys/imgs/part";export{t as P,s as a};
