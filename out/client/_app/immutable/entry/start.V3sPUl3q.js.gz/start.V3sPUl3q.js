import{l as o,c as r}from"../chunks/B5PH7vek.js";export{o as load_css,r as start};
